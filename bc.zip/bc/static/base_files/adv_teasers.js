window.ad_skip = 1;
